#pragma once

namespace $safeprojectname$ {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;


	public ref class MyForm : public System::Windows::Forms::Form
	{
	public:
		MyForm(void)
		{
			InitializeComponent();
		
		}

	protected:

		~MyForm()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Panel^ pn1;
	private: System::Windows::Forms::Panel^ pn2;
	private: System::Windows::Forms::Panel^ pn3;


	private: System::Windows::Forms::Panel^ panel2;


	

	private: System::Windows::Forms::Button^ btn1;
	private: System::Windows::Forms::Button^ btn2;
	private: System::Windows::Forms::Button^ btn3;
	private: System::Windows::Forms::Button^ btn4;
	private: System::Windows::Forms::Button^ btn5;
	
	private: System::Windows::Forms::Button^ btn7;
	private: System::Windows::Forms::Button^ btn8;
	private: System::Windows::Forms::Button^ btn9;



	private: System::Windows::Forms::Button^ button5;
	private: System::Windows::Forms::Button^ button6;
	private: System::Windows::Forms::Button^ button3;
	private: System::Windows::Forms::Button^ button2;







	private: System::Windows::Forms::Button^ pbtn12;
	private: System::Windows::Forms::Button^ pbtn13;









	protected: System::Windows::Forms::Label^ label3;
	private: System::Windows::Forms::Label^ label2;
	private: System::Windows::Forms::Label^ label1;

	private: System::Windows::Forms::Button^ btn6;
	private: System::Windows::Forms::Label^ plyX;

	private: System::Windows::Forms::Label^ ply0;


	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->pn1 = (gcnew System::Windows::Forms::Panel());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->panel2 = (gcnew System::Windows::Forms::Panel());
			this->pn3 = (gcnew System::Windows::Forms::Panel());
			this->plyX = (gcnew System::Windows::Forms::Label());
			this->ply0 = (gcnew System::Windows::Forms::Label());
			this->pbtn13 = (gcnew System::Windows::Forms::Button());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->pbtn12 = (gcnew System::Windows::Forms::Button());
			this->pn2 = (gcnew System::Windows::Forms::Panel());
			this->btn6 = (gcnew System::Windows::Forms::Button());
			this->btn9 = (gcnew System::Windows::Forms::Button());
			this->btn8 = (gcnew System::Windows::Forms::Button());
			this->btn7 = (gcnew System::Windows::Forms::Button());
			this->btn5 = (gcnew System::Windows::Forms::Button());
			this->btn4 = (gcnew System::Windows::Forms::Button());
			this->btn3 = (gcnew System::Windows::Forms::Button());
			this->btn2 = (gcnew System::Windows::Forms::Button());
			this->button6 = (gcnew System::Windows::Forms::Button());
			this->button5 = (gcnew System::Windows::Forms::Button());
			this->button3 = (gcnew System::Windows::Forms::Button());
			this->button2 = (gcnew System::Windows::Forms::Button());
			this->btn1 = (gcnew System::Windows::Forms::Button());
			this->pn1->SuspendLayout();
			this->panel2->SuspendLayout();
			this->pn3->SuspendLayout();
			this->pn2->SuspendLayout();
			this->SuspendLayout();
			// 
			// pn1
			// 
			this->pn1->Controls->Add(this->label3);
			this->pn1->Location = System::Drawing::Point(12, 24);
			this->pn1->Name = L"pn1";
			this->pn1->Size = System::Drawing::Size(778, 81);
			this->pn1->TabIndex = 1;
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Font = (gcnew System::Drawing::Font(L"HP Simplified Hans", 36, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label3->Location = System::Drawing::Point(15, 16);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(359, 55);
			this->label3->TabIndex = 0;
			this->label3->Text = L"Tic tac toe game";
			this->label3->Click += gcnew System::EventHandler(this, &MyForm::label3_Click);
			// 
			// panel2
			// 
			this->panel2->Controls->Add(this->pn3);
			this->panel2->Controls->Add(this->pn2);
			this->panel2->Location = System::Drawing::Point(12, 124);
			this->panel2->Name = L"panel2";
			this->panel2->Size = System::Drawing::Size(778, 286);
			this->panel2->TabIndex = 2;
			// 
			// pn3
			// 
			this->pn3->Controls->Add(this->plyX);
			this->pn3->Controls->Add(this->ply0);
			this->pn3->Controls->Add(this->pbtn13);
			this->pn3->Controls->Add(this->label2);
			this->pn3->Controls->Add(this->label1);
			this->pn3->Controls->Add(this->pbtn12);
			this->pn3->Location = System::Drawing::Point(393, 17);
			this->pn3->Name = L"pn3";
			this->pn3->Size = System::Drawing::Size(346, 247);
			this->pn3->TabIndex = 3;
			this->pn3->Paint += gcnew System::Windows::Forms::PaintEventHandler(this, &MyForm::panel4_Paint);
			// 
			// plyX
			// 
			this->plyX->BackColor = System::Drawing::SystemColors::ControlLightLight;
			this->plyX->Font = (gcnew System::Drawing::Font(L"Han Santteut Dotum", 14.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(129)));
			this->plyX->Location = System::Drawing::Point(169, 57);
			this->plyX->Name = L"plyX";
			this->plyX->Size = System::Drawing::Size(150, 30);
			this->plyX->TabIndex = 11;
			this->plyX->Text = L"0";
			this->plyX->TextAlign = System::Drawing::ContentAlignment::MiddleCenter;
			// 
			// ply0
			// 
			this->ply0->BackColor = System::Drawing::SystemColors::ControlLightLight;
			this->ply0->Enabled = false;
			this->ply0->Font = (gcnew System::Drawing::Font(L"Han Santteut Dotum", 14.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(129)));
			this->ply0->Location = System::Drawing::Point(169, 17);
			this->ply0->Name = L"ply0";
			this->ply0->Size = System::Drawing::Size(150, 30);
			this->ply0->TabIndex = 10;
			this->ply0->Text = L"0";
			this->ply0->TextAlign = System::Drawing::ContentAlignment::MiddleCenter;
			this->ply0->Click += gcnew System::EventHandler(this, &MyForm::ply0_Click);
			// 
			// pbtn13
			// 
			this->pbtn13->FlatStyle = System::Windows::Forms::FlatStyle::System;
			this->pbtn13->Font = (gcnew System::Drawing::Font(L"HYGothic-Extra", 14.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(129)));
			this->pbtn13->Location = System::Drawing::Point(171, 165);
			this->pbtn13->Name = L"pbtn13";
			this->pbtn13->Size = System::Drawing::Size(162, 58);
			this->pbtn13->TabIndex = 9;
			this->pbtn13->Text = L"Reset";
			this->pbtn13->UseVisualStyleBackColor = true;
			this->pbtn13->Click += gcnew System::EventHandler(this, &MyForm::pbtn13_Click);
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Font = (gcnew System::Drawing::Font(L"HP Simplified Hans", 15.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label2->Location = System::Drawing::Point(28, 61);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(84, 24);
			this->label2->TabIndex = 6;
			this->label2->Text = L"Player X";
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Font = (gcnew System::Drawing::Font(L"HP Simplified Hans", 15.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label1->Location = System::Drawing::Point(28, 16);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(85, 24);
			this->label1->TabIndex = 4;
			this->label1->Text = L"Player O";
			// 
			// pbtn12
			// 
			this->pbtn12->FlatStyle = System::Windows::Forms::FlatStyle::System;
			this->pbtn12->Font = (gcnew System::Drawing::Font(L"HYGothic-Extra", 14.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(129)));
			this->pbtn12->Location = System::Drawing::Point(3, 165);
			this->pbtn12->Name = L"pbtn12";
			this->pbtn12->Size = System::Drawing::Size(162, 58);
			this->pbtn12->TabIndex = 2;
			this->pbtn12->Text = L"New game ";
			this->pbtn12->UseVisualStyleBackColor = true;
			this->pbtn12->Click += gcnew System::EventHandler(this, &MyForm::pbtn12_Click);
			// 
			// pn2
			// 
			this->pn2->Controls->Add(this->btn6);
			this->pn2->Controls->Add(this->btn9);
			this->pn2->Controls->Add(this->btn8);
			this->pn2->Controls->Add(this->btn7);
			this->pn2->Controls->Add(this->btn5);
			this->pn2->Controls->Add(this->btn4);
			this->pn2->Controls->Add(this->btn3);
			this->pn2->Controls->Add(this->btn2);
			this->pn2->Controls->Add(this->button6);
			this->pn2->Controls->Add(this->button5);
			this->pn2->Controls->Add(this->button3);
			this->pn2->Controls->Add(this->button2);
			this->pn2->Controls->Add(this->btn1);
			this->pn2->Location = System::Drawing::Point(25, 17);
			this->pn2->Name = L"pn2";
			this->pn2->Size = System::Drawing::Size(343, 247);
			this->pn2->TabIndex = 2;
			// 
			// btn6
			// 
			this->btn6->FlatStyle = System::Windows::Forms::FlatStyle::System;
			this->btn6->Font = (gcnew System::Drawing::Font(L"HYGothic-Extra", 24, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(129)));
			this->btn6->Location = System::Drawing::Point(198, 91);
			this->btn6->Name = L"btn6";
			this->btn6->Size = System::Drawing::Size(71, 58);
			this->btn6->TabIndex = 17;
			this->btn6->UseVisualStyleBackColor = true;
			this->btn6->Click += gcnew System::EventHandler(this, &MyForm::btn6_Click);
			// 
			// btn9
			// 
			this->btn9->FlatStyle = System::Windows::Forms::FlatStyle::System;
			this->btn9->Font = (gcnew System::Drawing::Font(L"HYGothic-Extra", 24, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(129)));
			this->btn9->Location = System::Drawing::Point(198, 155);
			this->btn9->Name = L"btn9";
			this->btn9->Size = System::Drawing::Size(71, 58);
			this->btn9->TabIndex = 16;
			this->btn9->UseVisualStyleBackColor = true;
			this->btn9->Click += gcnew System::EventHandler(this, &MyForm::btn9_Click);
			// 
			// btn8
			// 
			this->btn8->FlatStyle = System::Windows::Forms::FlatStyle::System;
			this->btn8->Font = (gcnew System::Drawing::Font(L"HYGothic-Extra", 24, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(129)));
			this->btn8->Location = System::Drawing::Point(121, 155);
			this->btn8->Name = L"btn8";
			this->btn8->Size = System::Drawing::Size(71, 58);
			this->btn8->TabIndex = 15;
			this->btn8->UseVisualStyleBackColor = true;
			this->btn8->Click += gcnew System::EventHandler(this, &MyForm::btn8_Click);
			// 
			// btn7
			// 
			this->btn7->FlatStyle = System::Windows::Forms::FlatStyle::System;
			this->btn7->Font = (gcnew System::Drawing::Font(L"HYGothic-Extra", 24, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(129)));
			this->btn7->Location = System::Drawing::Point(44, 155);
			this->btn7->Name = L"btn7";
			this->btn7->Size = System::Drawing::Size(71, 58);
			this->btn7->TabIndex = 14;
			this->btn7->UseVisualStyleBackColor = true;
			this->btn7->Click += gcnew System::EventHandler(this, &MyForm::btn7_Click);
			// 
			// btn5
			// 
			this->btn5->FlatStyle = System::Windows::Forms::FlatStyle::System;
			this->btn5->Font = (gcnew System::Drawing::Font(L"HYGothic-Extra", 24, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(129)));
			this->btn5->Location = System::Drawing::Point(121, 91);
			this->btn5->Name = L"btn5";
			this->btn5->Size = System::Drawing::Size(71, 58);
			this->btn5->TabIndex = 12;
			this->btn5->UseVisualStyleBackColor = true;
			this->btn5->Click += gcnew System::EventHandler(this, &MyForm::btn5_Click);
			// 
			// btn4
			// 
			this->btn4->FlatStyle = System::Windows::Forms::FlatStyle::System;
			this->btn4->Font = (gcnew System::Drawing::Font(L"HYGothic-Extra", 24, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(129)));
			this->btn4->Location = System::Drawing::Point(44, 91);
			this->btn4->Name = L"btn4";
			this->btn4->Size = System::Drawing::Size(71, 58);
			this->btn4->TabIndex = 11;
			this->btn4->UseVisualStyleBackColor = true;
			this->btn4->Click += gcnew System::EventHandler(this, &MyForm::btn4_Click);
			// 
			// btn3
			// 
			this->btn3->FlatStyle = System::Windows::Forms::FlatStyle::System;
			this->btn3->Font = (gcnew System::Drawing::Font(L"HYGothic-Extra", 24, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(129)));
			this->btn3->Location = System::Drawing::Point(198, 27);
			this->btn3->Name = L"btn3";
			this->btn3->Size = System::Drawing::Size(71, 58);
			this->btn3->TabIndex = 10;
			this->btn3->UseVisualStyleBackColor = true;
			this->btn3->Click += gcnew System::EventHandler(this, &MyForm::btn3_Click);
			// 
			// btn2
			// 
			this->btn2->FlatStyle = System::Windows::Forms::FlatStyle::System;
			this->btn2->Font = (gcnew System::Drawing::Font(L"HYGothic-Extra", 24, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(129)));
			this->btn2->Location = System::Drawing::Point(121, 27);
			this->btn2->Name = L"btn2";
			this->btn2->Size = System::Drawing::Size(71, 58);
			this->btn2->TabIndex = 9;
			this->btn2->UseVisualStyleBackColor = true;
			this->btn2->Click += gcnew System::EventHandler(this, &MyForm::btn2_Click);
			// 
			// button6
			// 
			this->button6->Location = System::Drawing::Point(192, 120);
			this->button6->Name = L"button6";
			this->button6->Size = System::Drawing::Size(0, 0);
			this->button6->TabIndex = 5;
			this->button6->Text = L"button6";
			this->button6->UseVisualStyleBackColor = true;
			// 
			// button5
			// 
			this->button5->Location = System::Drawing::Point(115, 120);
			this->button5->Name = L"button5";
			this->button5->Size = System::Drawing::Size(0, 0);
			this->button5->TabIndex = 4;
			this->button5->Text = L"button5";
			this->button5->UseVisualStyleBackColor = true;
			// 
			// button3
			// 
			this->button3->Location = System::Drawing::Point(191, 56);
			this->button3->Name = L"button3";
			this->button3->Size = System::Drawing::Size(0, 0);
			this->button3->TabIndex = 2;
			this->button3->Text = L"button3";
			this->button3->UseVisualStyleBackColor = true;
			// 
			// button2
			// 
			this->button2->Location = System::Drawing::Point(114, 56);
			this->button2->Name = L"button2";
			this->button2->Size = System::Drawing::Size(0, 0);
			this->button2->TabIndex = 1;
			this->button2->Text = L"button2";
			this->button2->UseVisualStyleBackColor = true;
			// 
			// btn1
			// 
			this->btn1->FlatStyle = System::Windows::Forms::FlatStyle::System;
			this->btn1->Font = (gcnew System::Drawing::Font(L"HYGothic-Extra", 24, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(129)));
			this->btn1->Location = System::Drawing::Point(43, 27);
			this->btn1->Name = L"btn1";
			this->btn1->Size = System::Drawing::Size(71, 58);
			this->btn1->TabIndex = 0;
			this->btn1->UseVisualStyleBackColor = true;
			this->btn1->Click += gcnew System::EventHandler(this, &MyForm::btn1_Click);
			// 
			// MyForm
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(7, 12);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackColor = System::Drawing::SystemColors::InactiveCaption;
			this->ClientSize = System::Drawing::Size(830, 458);
			this->Controls->Add(this->panel2);
			this->Controls->Add(this->pn1);
			this->Name = L"MyForm";
			this->Text = L"MyForm";
			this->Load += gcnew System::EventHandler(this, &MyForm::MyForm_Load);
			this->pn1->ResumeLayout(false);
			this->pn1->PerformLayout();
			this->panel2->ResumeLayout(false);
			this->pn3->ResumeLayout(false);
			this->pn3->PerformLayout();
			this->pn2->ResumeLayout(false);
			this->ResumeLayout(false);

		}
#pragma endregion
	private: System::Void MyForm_Load(System::Object^ sender, System::EventArgs^ e) {
	}
	private: System::Void button1_Click(System::Object^ sender, System::EventArgs^ e) {

	}
	
private: System::Void label3_Click(System::Object^ sender, System::EventArgs^ e) {

}
private: System::Void label4_Click(System::Object^ sender, System::EventArgs^ e) {

}


	   Boolean checker;
	   int plusone=0;


	   void enable_false()
	   {
		   btn1 -> Enabled = false;
		   btn2->Enabled = false;
		   btn3->Enabled = false;
		   btn4->Enabled = false;
		   btn5->Enabled = false;
	
		   btn7->Enabled = false;
		   btn8->Enabled = false;
		   btn9->Enabled = false;

	   }
	   void score()
	   {
		   //if statement for x /////////////////////////////////////////////////////////
		   if (btn1->Text == "X" && btn2->Text == "X" && btn3->Text == "X")
		   {
			   btn1->BackColor = System::Drawing::Color::PowderBlue;
			   btn2->BackColor = System::Drawing::Color::PowderBlue;
			   btn3->BackColor = System::Drawing::Color::PowderBlue;
			   MessageBox::Show("Winner is X ", "Tic tac toe", MessageBoxButtons::OK, MessageBoxIcon::Information);
			   plusone = int::Parse(plyX->Text);
			   plyX->Text = Convert::ToString(plusone + 1);
			   enable_false();
		   }
		   if (btn1->Text == "X" && btn4->Text == "X" && btn7->Text == "X")
		   {
			   btn1->BackColor = System::Drawing::Color::PowderBlue;
			   btn4->BackColor = System::Drawing::Color::PowderBlue;
			   btn7->BackColor = System::Drawing::Color::PowderBlue;
			   MessageBox::Show("Winner is X ", "Tic tac toe", MessageBoxButtons::OK, MessageBoxIcon::Information);
			   plusone = int::Parse(plyX->Text);
			   plyX->Text = Convert::ToString(plusone + 1);
			   enable_false();
		   }
		   if (btn1->Text == "X" && btn5->Text == "X" && btn9->Text == "X")
		   {
			   btn1->BackColor = System::Drawing::Color::PowderBlue;
			   btn5->BackColor = System::Drawing::Color::PowderBlue;
			   btn9->BackColor = System::Drawing::Color::PowderBlue;
			   MessageBox::Show("Winner is X ", "Tic tac toe", MessageBoxButtons::OK, MessageBoxIcon::Information);
			   plusone = int::Parse(plyX->Text);
			   plyX->Text = Convert::ToString(plusone + 1);
			   enable_false();
		   }
		   if (btn1->Text == "X" && btn5->Text == "X" && btn9->Text == "X")
		   {
			   btn1->BackColor = System::Drawing::Color::PowderBlue;
			   btn5->BackColor = System::Drawing::Color::PowderBlue;
			   btn9->BackColor = System::Drawing::Color::PowderBlue;
			   MessageBox::Show("Winner is X ", "Tic tac toe", MessageBoxButtons::OK, MessageBoxIcon::Information);
			   plusone = int::Parse(plyX->Text);
			   plyX->Text = Convert::ToString(plusone + 1);
			   enable_false();
		   }

		   if (btn4->Text == "X" && btn5->Text == "X" && btn6->Text == "X")
		   {
			   btn4->BackColor = System::Drawing::Color::PowderBlue;
			   btn5->BackColor = System::Drawing::Color::PowderBlue;
			   btn6->BackColor = System::Drawing::Color::PowderBlue;
			   MessageBox::Show("Winner is X ", "Tic tac toe", MessageBoxButtons::OK, MessageBoxIcon::Information);
			   plusone = int::Parse(plyX->Text);
			   plyX->Text = Convert::ToString(plusone + 1);
			   enable_false();
		   }
		   if (btn7->Text == "X" && btn8->Text == "X" && btn9->Text == "X")
		   {
			   btn7->BackColor = System::Drawing::Color::PowderBlue;
			   btn8->BackColor = System::Drawing::Color::PowderBlue;
			   btn9->BackColor = System::Drawing::Color::PowderBlue;
			   MessageBox::Show("Winner is X ", "Tic tac toe", MessageBoxButtons::OK, MessageBoxIcon::Information);
			   plusone = int::Parse(plyX->Text);
			   plyX->Text = Convert::ToString(plusone + 1);
			   enable_false();
		   }
		   if (btn2->Text == "X" && btn5->Text == "X" && btn8->Text == "X")
		   {
			   btn2->BackColor = System::Drawing::Color::PowderBlue;
			   btn5->BackColor = System::Drawing::Color::PowderBlue;
			   btn8->BackColor = System::Drawing::Color::PowderBlue;
			   MessageBox::Show("Winner is X ", "Tic tac toe", MessageBoxButtons::OK, MessageBoxIcon::Information);
			   plusone = int::Parse(plyX->Text);
			   plyX->Text = Convert::ToString(plusone + 1);
			   enable_false();
		   }
		   if (btn3->Text == "X" && btn6->Text == "X" && btn9->Text == "X")
		   {
			   btn3->BackColor = System::Drawing::Color::PowderBlue;
			   btn6->BackColor = System::Drawing::Color::PowderBlue;
			   btn9->BackColor = System::Drawing::Color::PowderBlue;
			   MessageBox::Show("Winner is X ", "Tic tac toe", MessageBoxButtons::OK, MessageBoxIcon::Information);
			   plusone = int::Parse(plyX->Text);
			   plyX->Text = Convert::ToString(plusone + 1);
			   enable_false();
		   }
		   if (btn3->Text == "X" && btn5->Text == "X" && btn7->Text == "X")
		   {
			   btn3->BackColor = System::Drawing::Color::PowderBlue;
			   btn5->BackColor = System::Drawing::Color::PowderBlue;
			   btn7->BackColor = System::Drawing::Color::PowderBlue;
			   MessageBox::Show("Winner is X ", "Tic tac toe", MessageBoxButtons::OK, MessageBoxIcon::Information);
			   plusone = int::Parse(plyX->Text);
			   plyX->Text = Convert::ToString(plusone + 1);
			   enable_false();
		   }
		   
		   
		   
		   
		   
		   
		   
		   
		   
		   // if statements for O  player000000000000000000000000000000000000000000000000

		   if (btn1->Text == "O" && btn2->Text == "O" && btn3->Text == "O")
		   {
			   btn1->BackColor = System::Drawing::Color::PowderBlue;
			   btn2->BackColor = System::Drawing::Color::PowderBlue;
			   btn3->BackColor = System::Drawing::Color::PowderBlue;
			   MessageBox::Show("Winner is 0 ", "Tic tac toe", MessageBoxButtons::OK, MessageBoxIcon::Information);
			   plusone = int::Parse(ply0->Text);
			   ply0->Text = Convert::ToString(plusone + 1);
			   enable_false();
		   }
		   if (btn1->Text == "O" && btn4->Text == "O" && btn7->Text == "O")
		   {
			   btn1->BackColor = System::Drawing::Color::PowderBlue;
			   btn4->BackColor = System::Drawing::Color::PowderBlue;
			   btn7->BackColor = System::Drawing::Color::PowderBlue;
			   MessageBox::Show("Winner is O ", "Tic tac toe", MessageBoxButtons::OK, MessageBoxIcon::Information);
			   plusone = int::Parse(ply0->Text);
			   ply0->Text = Convert::ToString(plusone + 1);
			   enable_false();
		   }
		   if (btn1->Text == "O" && btn5->Text == "O" && btn9->Text == "O")
		   {
			   btn1->BackColor = System::Drawing::Color::PowderBlue;
			   btn5->BackColor = System::Drawing::Color::PowderBlue;
			   btn9->BackColor = System::Drawing::Color::PowderBlue;
			   MessageBox::Show("Winner is O ", "Tic tac toe", MessageBoxButtons::OK, MessageBoxIcon::Information);
			   plusone = int::Parse(ply0->Text);
			   ply0->Text = Convert::ToString(plusone + 1);
			   enable_false();
		   }
		   if (btn1->Text == "O" && btn5->Text == "O" && btn9->Text == "O")
		   {
			   btn1->BackColor = System::Drawing::Color::PowderBlue;
			   btn5->BackColor = System::Drawing::Color::PowderBlue;
			   btn9->BackColor = System::Drawing::Color::PowderBlue;
			   MessageBox::Show("Winner is O ", "Tic tac toe", MessageBoxButtons::OK, MessageBoxIcon::Information);
			   plusone = int::Parse(ply0->Text);
			   ply0->Text = Convert::ToString(plusone + 1);
			   enable_false();
		   }

		   if (btn4->Text == "O" && btn5->Text == "O" && btn6->Text == "O")
		   {
			   btn4->BackColor = System::Drawing::Color::PowderBlue;
			   btn5->BackColor = System::Drawing::Color::PowderBlue;
			   btn6->BackColor = System::Drawing::Color::PowderBlue;
			   MessageBox::Show("Winner is O ", "Tic tac toe", MessageBoxButtons::OK, MessageBoxIcon::Information);
			   plusone = int::Parse(ply0->Text);
			   ply0->Text = Convert::ToString(plusone + 1);
			   enable_false();
		   }
		   if (btn7->Text == "O" && btn8->Text == "O" && btn9->Text == "O")
		   {
			   btn7->BackColor = System::Drawing::Color::PowderBlue;
			   btn8->BackColor = System::Drawing::Color::PowderBlue;
			   btn9->BackColor = System::Drawing::Color::PowderBlue;
			   MessageBox::Show("Winner is O ", "Tic tac toe", MessageBoxButtons::OK, MessageBoxIcon::Information);
			   plusone = int::Parse(ply0->Text);
			   ply0->Text = Convert::ToString(plusone + 1);
			   enable_false();
		   }
		   if (btn2->Text == "O" && btn5->Text == "O" && btn8->Text == "O")
		   {
			   btn2->BackColor = System::Drawing::Color::PowderBlue;
			   btn5->BackColor = System::Drawing::Color::PowderBlue;
			   btn8->BackColor = System::Drawing::Color::PowderBlue;
			   MessageBox::Show("Winner is O ", "Tic tac toe", MessageBoxButtons::OK, MessageBoxIcon::Information);
			   plusone = int::Parse(ply0->Text);
			   ply0->Text = Convert::ToString(plusone + 1);
			   enable_false();
		   }
		   if (btn3->Text == "O" && btn6->Text == "O" && btn9->Text == "O")
		   {
			   btn3->BackColor = System::Drawing::Color::PowderBlue;
			   btn6->BackColor = System::Drawing::Color::PowderBlue;
			   btn9->BackColor = System::Drawing::Color::PowderBlue;
			   MessageBox::Show("Winner is O ", "Tic tac toe", MessageBoxButtons::OK, MessageBoxIcon::Information);
			   plusone = int::Parse(ply0->Text);
			   ply0->Text = Convert::ToString(plusone + 1);
			   enable_false();
		   }
		   if (btn3->Text == "O" && btn5->Text == "O" && btn7->Text == "O")
		   {
			   btn3->BackColor = System::Drawing::Color::PowderBlue;
			   btn5->BackColor = System::Drawing::Color::PowderBlue;
			   btn7->BackColor = System::Drawing::Color::PowderBlue;
			   MessageBox::Show("Winner is O ", "Tic tac toe", MessageBoxButtons::OK, MessageBoxIcon::Information);
			   plusone = int::Parse(ply0->Text);
			   ply0->Text = Convert::ToString(plusone + 1);
			   enable_false();
		   }
	   }



private: System::Void panel4_Paint(System::Object^ sender, System::Windows::Forms::PaintEventArgs^ e) {
}
private: System::Void btn1_Click(System::Object^ sender, System::EventArgs^ e) {

	if (checker == false)
	{
		btn1->Text = "X";
		checker = true;
	}
	else
	{
		btn1->Text = "O";
		checker = false;
	}
	score();
	btn1->Enabled = false;
}
private: System::Void btn2_Click(System::Object^ sender, System::EventArgs^ e) {
	if (checker == false)
	{
		btn2->Text = "X";
		checker = true;
	}
	else
	{
		btn2->Text = "O";
		checker = false;
	}
	score();
	btn2->Enabled = false;
}
private: System::Void btn3_Click(System::Object^ sender, System::EventArgs^ e) {
	if (checker == false)
	{
		btn3->Text = "X";
		checker = true;
	}
	else
	{
		btn3->Text = "O";
		checker = false;
	}
	score();
	btn3->Enabled = false;
}
	   private: System::Void btn4_Click(System::Object^ sender, System::EventArgs^ e) {

		   if (checker == false)
		   {
			   btn4->Text = "X";
			   checker = true;
		   }
		   else
		   {
			   btn4->Text = "O";
			   checker = false;
		   }
		   score();
		   btn4->Enabled = false;
	   }



private: System::Void btn5_Click(System::Object^ sender, System::EventArgs^ e) {
	if (checker == false)
	{
		btn5->Text = "X";
		checker = true;
	}
	else
	{
		btn5->Text = "O";
		checker = false;
	}
	score();
	btn5->Enabled = false;
}





private: System::Void btn6_Click(System::Object^ sender, System::EventArgs^ e) {

	if (checker == false)
	{
		btn6->Text = "X";
		checker = true;
	}
	else
	{
		btn6->Text = "O";
		checker = false;
	}
	score();
	btn6->Enabled = false;
}
private: System::Void btn7_Click(System::Object^ sender, System::EventArgs^ e) {
	if (checker == false)
	{
		btn7->Text = "X";
		checker = true;
	}
	else
	{
		btn7->Text = "O";
		checker = false;
	}
	score();
	btn7->Enabled = false;
}




private: System::Void btn8_Click(System::Object^ sender, System::EventArgs^ e) {
	if (checker == false)
	{
		btn8->Text = "X";
		checker = true;
	}
	else
	{
		btn8->Text = "O";
		checker = false;
	}
	score();
	btn8->Enabled = false;
}
private: System::Void btn9_Click(System::Object^ sender, System::EventArgs^ e) {
	if (checker == false)
	{
		btn9->Text = "X";
		checker = true;
	}
	else
	{
		btn9->Text = "O";
		checker = false;
	}
	score();
	btn9->Enabled = false;
}
private: System::Void pbtn13_Click(System::Object^ sender, System::EventArgs^ e) {
	btn1->Enabled = true;
	btn2->Enabled = true;
	btn3->Enabled = true;
	btn4->Enabled = true;
	btn5->Enabled = true;
	btn6->Enabled = true;
	btn7->Enabled = true;
	btn8->Enabled = true;
	btn9->Enabled = true;

	btn1->Text = "";
	btn2->Text = "";
	btn3->Text = "";
	btn4->Text = "";
	btn5->Text = "";
	btn6->Text = "";
	btn7->Text = "";
	btn8->Text = "";
	btn9->Text = "";
	pbtn12->Enabled = true;


	btn1->BackColor = System::Drawing::Color::WhiteSmoke;
	btn2->BackColor = System::Drawing::Color::WhiteSmoke;
	btn3->BackColor = System::Drawing::Color::WhiteSmoke;
	btn4->BackColor = System::Drawing::Color::WhiteSmoke;
	btn5->BackColor = System::Drawing::Color::WhiteSmoke;
	btn6->BackColor = System::Drawing::Color::WhiteSmoke;
	btn7->BackColor = System::Drawing::Color::WhiteSmoke;
	btn8->BackColor = System::Drawing::Color::WhiteSmoke;
	btn9->BackColor = System::Drawing::Color::WhiteSmoke;

}






private: System::Void pbtn12_Click(System::Object^ sender, System::EventArgs^ e) {

	btn1->Enabled = true;
	btn2->Enabled = true;
	btn3->Enabled = true;
	btn4->Enabled = true;
	btn5->Enabled = true;
	btn6->Enabled = true;
	btn7->Enabled = true;
	btn8->Enabled = true;
	btn9->Enabled = true;

	btn1->Text = "";
	btn2->Text = "";
	btn3->Text = "";
	btn4->Text = "";
	btn5->Text = "";
	btn6->Text = "";
	btn7->Text = "";
	btn8->Text = "";
	btn9->Text = "";
	

	plyX->Text = "0";
	ply0->Text = "0";


	btn1->BackColor = System::Drawing::Color::WhiteSmoke;
	btn2->BackColor = System::Drawing::Color::WhiteSmoke;
	btn3->BackColor = System::Drawing::Color::WhiteSmoke;
	btn4->BackColor = System::Drawing::Color::WhiteSmoke;
	btn5->BackColor = System::Drawing::Color::WhiteSmoke;
	btn6->BackColor = System::Drawing::Color::WhiteSmoke;
	btn7->BackColor = System::Drawing::Color::WhiteSmoke;
	btn8->BackColor = System::Drawing::Color::WhiteSmoke;
	btn9->BackColor = System::Drawing::Color::WhiteSmoke;




}
private: System::Void ply0_Click(System::Object^ sender, System::EventArgs^ e) {
}
};
}
